# **SpawnType**

| **스폰 타입** |
| :--- |
## **Enums**

| **이름**| **설명** |
| :--- | :--- |
| **UseSpawnGroup** | **스폰 그룹을 사용** | 
| **UseTeamSpawn** | **팀 스폰을 사용** | 
| **UseSpawnPoint** | **스폰 포인트를 사용** | 
## **샘플**

