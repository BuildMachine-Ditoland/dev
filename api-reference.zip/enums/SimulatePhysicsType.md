# **SimulatePhysicsType**

| **물리 적용 타입** |
| :--- |
## **Enums**

| **이름**| **설명** |
| :--- | :--- |
| **None** | **물리 사용하지 않음** | 
| **OnlyServer** | **서버만 사용** | 
| **OnlyClient** | **클라만 사용** | 
| **Server_Client** | **서버, 클라 모두 사용** | 
