# DivideTeamType

## **DivideTeamType**

**팀을 나누는 방식**



## **Enums**

| **Name** | **Value** | **Description** |
| :--- | :---: | :--- |
| **Equal** | **0** | **현재 인원을 설정된 팀으로 균등하게 나눔** |
| **Order** | **1** | **설정된 팀에 순서대로 팀원 배치** |
| **Rate** | **2** | **팀에 설정된 비율 대로 팀을 나눔** |



## **Referenced by**

**SetTeamSetting**

