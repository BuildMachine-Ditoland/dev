# **RModeSequenceAnimStateSetting**

| **RModeAnimStateSettingBase의 자식 객체로, 단일 애니메이션을 플레이하는 애니메이션 상태를 설정하는 객체** |
| :--- |
## **함수**

| **void AddAnimationEvent(String EventName, float Time, protected_function function EventFunction)** |
| :--- |
| **애니메이션 이벤트 추가** |

| **void DeleteAnimationEven(String EventName)** |
| :--- |
| **애니메이션 이벤트 제거** |

