# **Input**

| **인풋 이벤트를 관리(설정, 해제)하는 객체** |
| :--- |
# **함수**

| **AddAxisKeyEvent(string Event, RModeKey Key, float Value)** |
| :--- |
| **축 이벤트 추가** |

| **AddActionKeyEvent(string Event, RModeKey Key)** |
| :--- |
| **키 이벤트 추가** |

| **RemoveAllAxisKeyEvent()** |
| :--- |
| **모든 축 이벤트 제거** |

| **RemoveAllActionKeyEvent()** |
| :--- |
| **모든 키 이벤트 제거** |

