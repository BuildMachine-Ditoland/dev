# **ObjectClient**

| **클라이언트 모드 오브젝트들(ObjectFXClient, ObjectSoundClient, ObjectPointLightClient 등)의 부모 객체.** |
| :--- |
## **함수**

| **SetVisibility(bool bNewVisibility)** |
| :--- |
| **가시성 설정** |

| **SetSimulatePhysics(bool bSimulatePhysics)** |
| :--- |
| **물리 적용 설정** |

