# **RModeBlendAnimState**

| **RModeAnimStateBase의 자식 객체로, 여러 애니메이션을 특정 값에 따라 블랜딩하는 애니메이션 상태 객체** |
| :--- |
## **함수**

| **AddBlendAnimation1(float BlendValue, string AnimResourceID)** |
| :--- |
| **블랜드 애니메이션 추가** |

| **AddBlendAnimation1(float BlendValue, string AnimResourceID, float InPlaySpeed)** |
| :--- |
| **블랜드 애니메이션 추가** |

