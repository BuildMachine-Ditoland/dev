# **RModeSequenceAnimState**

| **RModeAnimStateBase의 자식 객체로, 단일 애니메이션을 플레이하는 애니메이션 상태 객체** |
| :--- |
## **함수**

| **ChangeAnimation(string ResourceID)** |
| :--- |
| **애니메이션 변경** |

