# **ModeItemClient**

| **월드에 배치된 Item에 해당하는 스크립트 객체** |
| :--- |
## **함수**

| **AttachTo(RModeRemotePlayer* Player, Bone BoneType)** |
| :--- |
| **아이템을 플레이어에 붙이기** |

| **Detach()** |
| :--- |
| **플레이어에 붙어 있는 아이템 해제** |

| **AddAction(string ActionName, Key ActionKey, bool bAutoAction, LuaScriptFunction Function)** |
| :--- |
| **아이템 착용 후 액션 추가** |

| **AddToggleAction(string ActionName, Key ActionKey, LuaScriptFunction StartFunction, LuaScriptFunction EndFunction)** |
| :--- |
| **아이템 착용 후 토글 액션 추가** |

