# **ObjectPointLightClient**

| **월드에 배치된 Light에 해당하는 스크립트 객체** |
| :--- |
## **함수**

| **SetEnable(bool bEnable)** |
| :--- |
| **설정된 Point Light의 여부 설정** |

| **ChangeColor(Color ChangedColor)** |
| :--- |
| **컬러 변경** |

| **ChangeIntensity(float Intensity)** |
| :--- |
| **밝기 값 변경** |

