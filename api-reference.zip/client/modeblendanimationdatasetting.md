# **ModeBlendAnimationDataSetting**

| **RModeBlendAnimState 에 블랜드 애니메이션이 추가 될 때 생성되는 객체** |
| :--- |
| **void AddAnimationEvent(String EventName, float Time, protected_function function EventFunction)** |

| **애니메이션 이벤트 추가** |
| :--- |
| **void DeleteAnimationEven(String EventName)** |

| **애니메이션 이벤트 제거** |
| :--- |
