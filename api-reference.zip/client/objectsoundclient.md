# **ObjectSoundClient**

| **월드에 배치된 Sound에 해당하는 스크립트 객체** |
| :--- |
