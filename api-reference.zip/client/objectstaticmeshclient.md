# **ObjectStaticMeshClient**

| **월드에 배치된 StaticMesh에 해당하는 스크립트 객체** |
| :--- |
| **ChangeColor(Color ChangeColor)** |

| **메시의 컬러 변경** |
| :--- |
