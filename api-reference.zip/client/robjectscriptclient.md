# RObjectScriptClient

## **RObjectScriptClient**

**클라이언트에 제공되는 RObjectScript의 자식 객체.**

