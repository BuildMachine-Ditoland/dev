# **RModeSpawnPointGroup**

| **여러 스폰 포인트를 설정하고 그 중에 스폰하게 하는 객체. Game.AddSpawnPointGroup로 이용.** |
| :--- |
| **RModeSpawnPoint AddSpawnPoint(string SpawnPointName, RObjectScript* RObjectScript)** |

| **스폰 포인트 추가** |
| :--- |
| **SetSpawnType(GroupSpawnType GroupSpawnType)** |

| **그룹 작동방식 설정** |
| :--- |
