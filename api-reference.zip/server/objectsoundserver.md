# **ObjectSoundServer**

| **월드에 배치된 Sound에 해당하는 스크립트 객체** |
| :--- |
## **함수**

| **Play()** |
| :--- |
| **Sound 플레이** |

| **Stop()** |
| :--- |
| **Sound 정지** |

