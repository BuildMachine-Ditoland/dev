# **RObjectStaticMeshServer**

| **월드에 배치된 StaticMesh에 해당하는 스크립트 객체** |
| :--- |
## **함수**

| **ChangeColor(Color ChangeColor)** |
| :--- |
| **컬러 변경** |

| **SetSimulatePhysics(SimulatePhysicsType Type, bool bReplicate)** |
| :--- |
| **물리 설정 변경** |

