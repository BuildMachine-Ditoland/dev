# **ModeUISceneServer**

| **월드에 배치된 UI씬에 해당하는 스크립트 객체** |
| :--- |
## **함수**

| **SetVisibility(bool Visibility)** |
| :--- |
| **표시 여부 설정** |

