# **RModeUIServer**

| **서버에서 UI를 컨트롤 하는 객체. 서비스로 제공되며, UI로 참조가능** |
| :--- |
## **함수**

| **SetVisible(string InUISceneName, bool bVisible)** |
| :--- |
| **해당 UI 표시 여부 설정** |

