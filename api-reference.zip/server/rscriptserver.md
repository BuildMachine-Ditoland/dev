# **RScriptServer**

| **서버 스크립트에 "RScriptServer"로 제공되는 객체로 스크립트가 붙어있는 오브젝트를 Parent로 얻을 수 있다.** |
| :--- |
## **속성**

| **FRObjectScriptServer Parent** |
| :--- |
| **해당 스크립트가 붙어있는 오브젝트** |

