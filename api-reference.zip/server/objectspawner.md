# **ObjectSpawner**

| **월드상에 설정된 조건에 맞게 오브젝트를 생성하는 객체** |
| :--- |
## **함수**

| **AddSpawnObject(String ObjectName, float SpawnRate, int Count)** |
| :--- |
| **스폰 오브젝트 추가(ObjectName : 월드 트리 상 이름, SpawnRate : 스폰 확률, Count : 스폰 개수)** |

