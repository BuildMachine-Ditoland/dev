# **RModeSpawnPoint**

| **게임에서 캐릭터를 스폰하는데 사용되는 객체. Game.AddSpawnPoint로 이용** |
| :--- |
## **함수**

| **SetSpawnType(ESpawnType InSpawnType)** |
| :--- |
| **스폰 포인트 작동방식 설정** |

| **SetSpawnType(ESpawnType InSpawnType, float Radius)** |
| :--- |
| **스폰 포인트 작동방식 설정** |

