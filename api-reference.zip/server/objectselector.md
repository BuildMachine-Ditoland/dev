# **ObjectSelector**

| **설정된 조건에 맞는 오브젝트를 선택하는 객체** |
| :--- |
## **함수**

| **AddSelectObject(String ObjectName, float SelectRate, int Count)** |
| :--- |
| **선택 오브젝트 추가(ObjectName : 월드 트리 상 이름, SelectRate : 선택 확률, Count : 개수)** |

| **string GetNextSelectObject()** |
| :--- |
| **선택 오브젝트 얻기** |

