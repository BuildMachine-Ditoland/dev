# **GameStatisticsData**

| **게임 통계데이터** |
| :--- |
## **속성**

| **PlayerName** |
| :--- |
| **플레이어 이름** |

| **Value** |
| :--- |
| **int 값** |

