# RLogger

## **RLogger**

**스크립트 로그 출력.**

## **Function**

| **Log\(string message\)** |
| :--- |
| **일반 로그 메세지 출력.** |

| **Warning\(string message\)** |
| :--- |
| **경고 로그 메세지 출력.** |

| **Error\(string message\)** |
| :--- |
| **에러 로그 메세지 출력.** |

