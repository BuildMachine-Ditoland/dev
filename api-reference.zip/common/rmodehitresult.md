# **RModeHitResult**

| **충돌 체크에 대한 결과로 사용되는 개체** |
| :--- |
## **속성**

| **Vector HitLocation** |
| :--- |
| **충돌 위치** |

| **HitObject** |
| :--- |
