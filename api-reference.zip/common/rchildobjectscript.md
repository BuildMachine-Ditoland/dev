# RChildObjectScript

## **RChildObjectScript**

**월드에 생성되는 R오브젝트에 제공되는 객체**

## **Property**

| **var OnCreateEvent** |
| :--- |
| **생성 시 호출되는 이벤트 객체** |

| **var OnUpdateEvent** |
| :--- |
| **생성 후 매 프레임에 호출되는 이벤트 객체** |

| **var OnDestoryEvent** |
| :--- |
| **없어 질 때 호출되는 이벤트 객체** |

